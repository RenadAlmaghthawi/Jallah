package com.mycompany.jallah

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
