import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:math';
import 'dart:ui';
import '/index.dart';
import 'report_page_widget.dart' show ReportPageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ReportPageModel extends FlutterFlowModel<ReportPageWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode1;
  TextEditingController? emailAddressCreateTextController1;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController1Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode2;
  TextEditingController? emailAddressCreateTextController2;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController2Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode3;
  TextEditingController? emailAddressCreateTextController3;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController3Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode4;
  TextEditingController? emailAddressCreateTextController4;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController4Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode5;
  TextEditingController? emailAddressCreateTextController5;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController5Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode6;
  TextEditingController? emailAddressCreateTextController6;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController6Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode7;
  TextEditingController? emailAddressCreateTextController7;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController7Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode8;
  TextEditingController? emailAddressCreateTextController8;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController8Validator;
  // State field(s) for emailAddress_Create widget.
  FocusNode? emailAddressCreateFocusNode9;
  TextEditingController? emailAddressCreateTextController9;
  String? Function(BuildContext, String?)?
      emailAddressCreateTextController9Validator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    emailAddressCreateFocusNode1?.dispose();
    emailAddressCreateTextController1?.dispose();

    emailAddressCreateFocusNode2?.dispose();
    emailAddressCreateTextController2?.dispose();

    emailAddressCreateFocusNode3?.dispose();
    emailAddressCreateTextController3?.dispose();

    emailAddressCreateFocusNode4?.dispose();
    emailAddressCreateTextController4?.dispose();

    emailAddressCreateFocusNode5?.dispose();
    emailAddressCreateTextController5?.dispose();

    emailAddressCreateFocusNode6?.dispose();
    emailAddressCreateTextController6?.dispose();

    emailAddressCreateFocusNode7?.dispose();
    emailAddressCreateTextController7?.dispose();

    emailAddressCreateFocusNode8?.dispose();
    emailAddressCreateTextController8?.dispose();

    emailAddressCreateFocusNode9?.dispose();
    emailAddressCreateTextController9?.dispose();
  }
}
