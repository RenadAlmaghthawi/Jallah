import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VerificationCodesRecord extends FirestoreRecord {
  VerificationCodesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "code" field.
  String? _code;
  String get code => _code ?? '';
  bool hasCode() => _code != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "verified" field.
  bool? _verified;
  bool get verified => _verified ?? false;
  bool hasVerified() => _verified != null;

  // "userId" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  void _initializeFields() {
    _code = snapshotData['code'] as String?;
    _createdAt = snapshotData['createdAt'] as DateTime?;
    _verified = snapshotData['verified'] as bool?;
    _userId = snapshotData['userId'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('verification_codes');

  static Stream<VerificationCodesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VerificationCodesRecord.fromSnapshot(s));

  static Future<VerificationCodesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => VerificationCodesRecord.fromSnapshot(s));

  static VerificationCodesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VerificationCodesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VerificationCodesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VerificationCodesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VerificationCodesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VerificationCodesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVerificationCodesRecordData({
  String? code,
  DateTime? createdAt,
  bool? verified,
  String? userId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'code': code,
      'createdAt': createdAt,
      'verified': verified,
      'userId': userId,
    }.withoutNulls,
  );

  return firestoreData;
}

class VerificationCodesRecordDocumentEquality
    implements Equality<VerificationCodesRecord> {
  const VerificationCodesRecordDocumentEquality();

  @override
  bool equals(VerificationCodesRecord? e1, VerificationCodesRecord? e2) {
    return e1?.code == e2?.code &&
        e1?.createdAt == e2?.createdAt &&
        e1?.verified == e2?.verified &&
        e1?.userId == e2?.userId;
  }

  @override
  int hash(VerificationCodesRecord? e) => const ListEquality()
      .hash([e?.code, e?.createdAt, e?.verified, e?.userId]);

  @override
  bool isValidKey(Object? o) => o is VerificationCodesRecord;
}
