import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDK76d-aIrMFc4p3s2KMS8mgdVaxzY2ejs",
            authDomain: "jallah-82bc6.firebaseapp.com",
            projectId: "jallah-82bc6",
            storageBucket: "jallah-82bc6.firebasestorage.app",
            messagingSenderId: "467702468836",
            appId: "1:467702468836:web:c2ba6e3c4d13a308cf9cf1",
            measurementId: "G-1B6MDSGKDY"));
  } else {
    await Firebase.initializeApp();
  }
}
