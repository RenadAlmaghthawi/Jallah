import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCd-D1B19x34xQQszWAaQRWPwafMqwP79Y",
            authDomain: "jallah-i73011.firebaseapp.com",
            projectId: "jallah-i73011",
            storageBucket: "jallah-i73011.firebasestorage.app",
            messagingSenderId: "552062969342",
            appId: "1:552062969342:web:71810b0091d14e87eaccaf"));
  } else {
    await Firebase.initializeApp();
  }
}
