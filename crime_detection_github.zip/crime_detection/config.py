"""
Configuration for Crime Detection System
"""

import os
from dataclasses import dataclass, field
from typing import List


@dataclass
class Config:
    """Configuration for the Crime Detection System."""
    
    # Paths
    base_path: str = '/content/drive/MyDrive/DeepMIL'
    
    # Model architecture
    feature_size: int = 1024
    n_classes: int = 8
    dropout_rate: float = 0.6
    
    # Classes
    classes: List[str] = field(default_factory=lambda: [
        'Normal', 'Abuse', 'Assault', 'Burglary', 
        'Fighting', 'Robbery', 'Shoplifting', 'Stealing'
    ])
    target_crimes: List[str] = field(default_factory=lambda: [
        'Abuse', 'Assault', 'Burglary', 'Fighting', 
        'Robbery', 'Shoplifting', 'Stealing'
    ])
    
    # Training hyperparameters
    batch_size: int = 32
    num_segments: int = 32
    learning_rate: float = 0.00005
    weight_decay: float = 0.0001
    max_epochs: int = 100
    
    # Loss weights
    anomaly_loss_weight: float = 1.0
    classification_loss_weight: float = 1.0
    lambda_smooth: float = 8e-5
    lambda_sparse: float = 8e-5
    
    # Detection thresholds
    anomaly_threshold: float = 0.45
    min_anomaly_duration: int = 2
    
    # Video processing
    buffer_seconds: float = 30.0
    fps: int = 30
    frames_per_segment: int = 16
    
    # Data augmentation
    use_10crop_train: bool = True
    use_10crop_test: bool = True
    
    # System
    num_workers: int = 2
    device: str = 'cuda'
    
    def __post_init__(self):
        """Initialize derived paths."""
        self.train_features_dir = os.path.join(self.base_path, 'I3D', 'Train')
        self.test_features_dir = os.path.join(self.base_path, 'I3D', 'Test')
        self.pretrained_checkpoint = os.path.join(self.base_path, 'ckpt', 'deepmilfinal.pkl')
        self.checkpoints_dir = os.path.join(self.base_path, 'checkpoints')
        self.output_dir = os.path.join(self.base_path, 'outputs')
        
        os.makedirs(self.checkpoints_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)
    
    def get_class_idx(self, name: str) -> int:
        """Get class index by name."""
        return self.classes.index(name)
    
    def is_target_crime(self, name: str) -> bool:
        """Check if class is a target crime."""
        return name in self.target_crimes
