"""
Multi-Task Crime Detection Model (DeepMIL)
"""

import torch
import torch.nn as nn
import torch.nn.init as torch_init
import numpy as np


def weight_init(m):
    """Xavier initialization for Conv and Linear layers."""
    classname = m.__class__.__name__
    if classname.find('Conv') != -1 or classname.find('Linear') != -1:
        torch_init.xavier_uniform_(m.weight)
        if m.bias is not None:
            m.bias.data.fill_(0)


class MultiTaskCrimeModel(nn.Module):
    """
    Multi-task model for crime detection and classification.
    
    Outputs:
        - Anomaly scores (per segment)
        - Crime class logits (per segment)
    """
    
    CLASSES = ['Normal', 'Abuse', 'Assault', 'Burglary', 
               'Fighting', 'Robbery', 'Shoplifting', 'Stealing']
    
    def __init__(self, n_features=1024, n_classes=8, dropout_rate=0.6):
        super().__init__()
        
        self.n_features = n_features
        self.n_classes = n_classes
        
        # Shared feature extractor
        self.fc1 = nn.Linear(n_features, 512)
        self.fc2 = nn.Linear(512, 128)
        
        # Anomaly detection head
        self.anomaly_head = nn.Sequential(
            nn.Linear(128, 32),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(32, 1),
            nn.Sigmoid()
        )
        
        # Classification head
        self.class_head = nn.Sequential(
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(64, n_classes)
        )
        
        self.dropout = nn.Dropout(dropout_rate)
        self.relu = nn.ReLU()
        
        # Initialize weights
        self.apply(weight_init)
    
    def forward(self, x):
        """
        Forward pass.
        
        Args:
            x: Input tensor of shape (batch, segments, features) or (batch, features)
        
        Returns:
            anomaly_scores: (batch, segments, 1) or (batch, 1)
            class_logits: (batch, segments, n_classes) or (batch, n_classes)
        """
        orig_shape = x.shape
        
        # Handle 3D input (batch, segments, features)
        if len(orig_shape) == 3:
            bs, ns, f = orig_shape
            x = x.view(-1, f)
        
        # Forward through shared layers
        x = self.dropout(self.relu(self.fc1(x)))
        x = self.dropout(self.relu(self.fc2(x)))
        
        # Dual heads
        anomaly = self.anomaly_head(x)
        cls = self.class_head(x)
        
        # Reshape back if needed
        if len(orig_shape) == 3:
            anomaly = anomaly.view(bs, ns, 1)
            cls = cls.view(bs, ns, self.n_classes)
        
        return anomaly, cls
    
    def get_video_prediction(self, seg_anom, seg_cls, threshold=0.5):
        """
        Get video-level prediction from segment-level outputs.
        
        Args:
            seg_anom: Segment anomaly scores (segments, 1)
            seg_cls: Segment class logits (segments, n_classes)
            threshold: Anomaly threshold
        
        Returns:
            Dictionary with prediction results
        """
        with torch.no_grad():
            anom = seg_anom.squeeze(-1)
            max_score, max_idx = torch.max(anom, dim=0)
            
            # Get class prediction from anomalous segments
            anom_segs = anom > threshold
            if anom_segs.any():
                vid_logits = seg_cls[max_idx]
            else:
                vid_logits = seg_cls.mean(dim=0)
            
            probs = torch.softmax(vid_logits, dim=0)
            pred_idx = torch.argmax(probs).item()
            
            return {
                'is_anomaly': max_score.item() > threshold,
                'max_anomaly_score': max_score.item(),
                'max_anomaly_segment': max_idx.item(),
                'predicted_class': self.CLASSES[pred_idx],
                'predicted_class_idx': pred_idx,
                'confidence': probs[pred_idx].item(),
                'all_probabilities': {
                    self.CLASSES[i]: probs[i].item() 
                    for i in range(self.n_classes)
                },
                'segment_anomaly_scores': anom.cpu().numpy()
            }


def load_pretrained_weights(model, path):
    """
    Load pretrained weights from checkpoint.
    
    Args:
        model: MultiTaskCrimeModel instance
        path: Path to checkpoint file
    
    Returns:
        model with loaded weights
    """
    ckpt = torch.load(path, map_location='cpu')
    sd = {k.replace('module.', ''): v for k, v in ckpt.items()}
    
    # Load fc1 weights if shapes match
    if 'fc1.weight' in sd and model.fc1.weight.shape == sd['fc1.weight'].shape:
        model.fc1.weight.data = sd['fc1.weight']
        model.fc1.bias.data = sd['fc1.bias']
        print(f"✓ Loaded pretrained fc1 from {path}")
    
    return model
