"""
Suspect Identifier - Identify suspects in crime videos using YOLO
"""

import os
import cv2
import json
import numpy as np
from datetime import timedelta


class SuspectIdentifier:
    """
    Identify and track suspects in crime videos.
    
    Uses YOLO for person detection and simple tracking.
    """
    
    def __init__(self, anomaly_result, video_path, threshold=0.45, output_dir='./evidence'):
        """
        Initialize identifier.
        
        Args:
            anomaly_result: Result from CrimeDetector
            video_path: Path to video file
            threshold: Anomaly threshold
            output_dir: Directory to save evidence
        """
        self.result = anomaly_result
        self.video_path = video_path
        self.threshold = threshold
        self.output_dir = output_dir
        
        # Get video info
        cap = cv2.VideoCapture(video_path)
        self.fps = cap.get(cv2.CAP_PROP_FPS)
        self.total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        self.duration = self.total_frames / self.fps
        self.num_segments = len(anomaly_result['scores'])
        cap.release()
        
        # Load YOLO
        try:
            from ultralytics import YOLO
            print("Loading YOLO model...")
            self.yolo = YOLO('yolov8n.pt')
        except ImportError:
            print("⚠️ ultralytics not installed. Run: pip install ultralytics")
            self.yolo = None
    
    def _get_crime_window(self):
        """Get the time window of detected crime."""
        scores = self.result['scores']
        
        # Find segments above threshold
        above = [i for i, s in enumerate(scores) if s > self.threshold]
        
        if not above:
            return None, None
        
        start_seg = min(above)
        end_seg = max(above) + 1
        
        seg_duration = self.duration / self.num_segments
        start_time = start_seg * seg_duration
        end_time = end_seg * seg_duration
        
        return start_time, end_time
    
    def run(self, buffer_before=30, buffer_after=15, sample_fps=2.0):
        """
        Run suspect identification.
        
        Args:
            buffer_before: Seconds to analyze before crime
            buffer_after: Seconds to analyze after crime
            sample_fps: Frames per second to analyze
        
        Returns:
            Dictionary with suspects, bystanders, and vehicles
        """
        if self.yolo is None:
            return {'error': 'YOLO not available'}
        
        crime_start, crime_end = self._get_crime_window()
        
        if crime_start is None:
            return {'error': 'No crime detected'}
        
        print(f"✅ Video: {self.duration:.1f}s, {self.fps:.1f}fps, {self.num_segments} segments")
        print(f"\n🔴 Crime window: {crime_start:.1f}s - {crime_end:.1f}s")
        
        # Analysis window
        analysis_start = max(0, crime_start - buffer_before)
        analysis_end = min(self.duration, crime_end + buffer_after)
        
        print(f"🔍 Processing {analysis_end - analysis_start:.1f}s of video...")
        
        # Setup output directory
        video_name = os.path.splitext(os.path.basename(self.video_path))[0]
        evidence_dir = os.path.join(self.output_dir, video_name)
        os.makedirs(os.path.join(evidence_dir, 'suspects'), exist_ok=True)
        os.makedirs(os.path.join(evidence_dir, 'vehicles'), exist_ok=True)
        
        # Track persons
        cap = cv2.VideoCapture(self.video_path)
        persons = {}  # person_id -> {detections, first_seen, last_seen}
        vehicles = []
        person_id_counter = 0
        
        frame_interval = int(self.fps / sample_fps)
        current_frame = int(analysis_start * self.fps)
        
        while current_frame < analysis_end * self.fps:
            cap.set(cv2.CAP_PROP_POS_FRAMES, current_frame)
            ret, frame = cap.read()
            
            if not ret:
                break
            
            timestamp = current_frame / self.fps
            
            # Run YOLO
            results = self.yolo(frame, verbose=False)[0]
            
            frame_persons = []
            
            for box in results.boxes:
                cls = int(box.cls[0])
                conf = float(box.conf[0])
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                
                if cls == 0 and conf > 0.5:  # Person
                    center = ((x1 + x2) // 2, (y1 + y2) // 2)
                    
                    # Simple tracking: match to existing person by proximity
                    matched_id = None
                    min_dist = 100  # Max distance for matching
                    
                    for pid, pdata in persons.items():
                        if pdata['detections']:
                            last_det = pdata['detections'][-1]
                            dist = np.sqrt(
                                (center[0] - last_det['center'][0])**2 +
                                (center[1] - last_det['center'][1])**2
                            )
                            if dist < min_dist:
                                min_dist = dist
                                matched_id = pid
                    
                    if matched_id is None:
                        matched_id = person_id_counter
                        persons[matched_id] = {
                            'detections': [],
                            'first_seen': timestamp,
                            'last_seen': timestamp
                        }
                        person_id_counter += 1
                    
                    persons[matched_id]['detections'].append({
                        'timestamp': timestamp,
                        'bbox': [x1, y1, x2, y2],
                        'center': list(center)
                    })
                    persons[matched_id]['last_seen'] = timestamp
                    frame_persons.append(matched_id)
                
                elif cls in [2, 3, 5, 7] and conf > 0.5:  # Vehicles
                    vehicles.append({
                        'timestamp': timestamp,
                        'bbox': [x1, y1, x2, y2],
                        'class': cls,
                        'confidence': conf
                    })
            
            current_frame += frame_interval
            
            if len(persons) > 0 and current_frame % (frame_interval * 30) < frame_interval:
                print(f"   {current_frame} frames, {len(persons)} people tracked")
        
        cap.release()
        print(f"   ✅ Done: {current_frame} frames processed")
        
        # Classify persons as suspects or bystanders
        suspects = []
        bystanders = []
        
        for pid, pdata in persons.items():
            # Calculate suspicion score
            score = 0
            reasons = []
            
            first = pdata['first_seen']
            last = pdata['last_seen']
            
            # Present during crime
            if first <= crime_end and last >= crime_start:
                score += 25
                reasons.append(f"Present during crime ({crime_start:.1f}s - {crime_end:.1f}s)")
            
            # Appeared right before/during crime
            if crime_start - 10 <= first <= crime_end:
                score += 25
                reasons.append(f"Appeared during crime ({first:.1f}s)")
            
            # Left immediately after
            if crime_start <= last <= crime_end + 10:
                score += 25
                reasons.append(f"Left immediately after ({last:.1f}s)")
            
            # Only visible during crime window
            if first >= crime_start - 5 and last <= crime_end + 5:
                score += 25
                reasons.append("Only visible during crime window")
            
            person_data = {
                'person_id': pid,
                'first_seen': first,
                'last_seen': last,
                'detections': pdata['detections'],
                'suspicion_score': score,
                'reasons': reasons,
                'classification': 'SUSPECT' if score >= 50 else 'BYSTANDER'
            }
            
            if score >= 50:
                suspects.append(person_data)
                self._save_suspect_image(cap, pdata, pid, score, evidence_dir)
            else:
                bystanders.append(person_data)
        
        # Sort suspects by score
        suspects.sort(key=lambda x: x['suspicion_score'], reverse=True)
        
        print(f"💾 Saved to: {evidence_dir}")
        print(f"\n📊 Results: {len(suspects)} suspects, {len(bystanders)} bystanders, {len(vehicles)} vehicles")
        
        for i, s in enumerate(suspects[:5]):
            print(f"\n🚨 Suspect #{i+1} (Score: {s['suspicion_score']})")
            for r in s['reasons']:
                print(f"   - {r}")
        
        return {
            'video_id': self.result['video_id'],
            'crime_window': {
                'start': crime_start,
                'end': crime_end
            },
            'suspects': suspects,
            'bystanders': bystanders,
            'vehicles': vehicles,
            'evidence': {
                'suspects': [
                    os.path.join(evidence_dir, 'suspects', f)
                    for f in os.listdir(os.path.join(evidence_dir, 'suspects'))
                ] if os.path.exists(os.path.join(evidence_dir, 'suspects')) else [],
                'vehicles': []
            }
        }
    
    def _save_suspect_image(self, cap, pdata, pid, score, evidence_dir):
        """Save suspect image from best detection."""
        if not pdata['detections']:
            return
        
        # Get middle detection
        det = pdata['detections'][len(pdata['detections']) // 2]
        
        cap = cv2.VideoCapture(self.video_path)
        cap.set(cv2.CAP_PROP_POS_MSEC, det['timestamp'] * 1000)
        ret, frame = cap.read()
        cap.release()
        
        if not ret:
            return
        
        # Crop person with padding
        x1, y1, x2, y2 = det['bbox']
        pad = 20
        x1, y1 = max(0, x1 - pad), max(0, y1 - pad)
        x2 = min(frame.shape[1], x2 + pad)
        y2 = min(frame.shape[0], y2 + pad)
        
        crop = frame[y1:y2, x1:x2]
        
        save_path = os.path.join(
            evidence_dir, 'suspects',
            f'suspect_{pid:03d}_score{score}.jpg'
        )
        cv2.imwrite(save_path, crop)
