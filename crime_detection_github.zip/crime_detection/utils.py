"""
Utility functions for Crime Detection System
"""

import os
import cv2
import json
import numpy as np
from datetime import datetime, timedelta


def extract_crime_clip(video_path, crime_start, crime_end, output_path, buffer=30):
    """
    Extract video clip around crime with overlay.
    
    Args:
        video_path: Path to source video
        crime_start: Crime start time in seconds
        crime_end: Crime end time in seconds
        output_path: Path to save clip
        buffer: Buffer before/after crime in seconds
    """
    cap = cv2.VideoCapture(video_path)
    fps = cap.get(cv2.CAP_PROP_FPS)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    duration = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) / fps
    
    start_time = max(0, crime_start - buffer)
    end_time = min(duration, crime_end + buffer)
    start_frame = int(start_time * fps)
    end_frame = int(end_time * fps)
    
    print(f"📹 Extracting: {start_time:.1f}s - {end_time:.1f}s")
    
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
    
    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    frame_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret or cap.get(cv2.CAP_PROP_POS_FRAMES) > end_frame:
            break
        
        current_time = (start_frame + frame_count) / fps
        is_crime = crime_start <= current_time <= crime_end
        
        # Add timestamp
        time_str = str(timedelta(seconds=int(current_time)))[2:]
        cv2.putText(frame, time_str, (10, 22), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Add status indicator
        if is_crime:
            cv2.rectangle(frame, (width-60, 8), (width-10, 28), (0, 0, 200), -1)
            cv2.putText(frame, "CRIME", (width-56, 23),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
            cv2.rectangle(frame, (2, 2), (width-3, height-3), (0, 0, 200), 2)
        else:
            cv2.rectangle(frame, (width-45, 8), (width-10, 28), (0, 150, 0), -1)
            cv2.putText(frame, "REC", (width-40, 23),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        
        out.write(frame)
        frame_count += 1
    
    cap.release()
    out.release()
    print(f"✅ Saved: {output_path} ({frame_count} frames)")


def extract_key_frames(video_path, crime_start, crime_end, output_dir, num_frames=6):
    """
    Extract key frames from crime window.
    
    Args:
        video_path: Path to video
        crime_start: Crime start time
        crime_end: Crime end time
        output_dir: Directory to save frames
        num_frames: Number of frames to extract
    """
    frames_dir = os.path.join(output_dir, 'frames')
    os.makedirs(frames_dir, exist_ok=True)
    
    cap = cv2.VideoCapture(video_path)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    
    timestamps = np.linspace(crime_start, crime_end, num_frames)
    
    for i, t in enumerate(timestamps):
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ret, frame = cap.read()
        
        if not ret:
            continue
        
        # Add timestamp
        cv2.putText(frame, str(timedelta(seconds=int(t)))[2:], (10, height-15),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        cv2.imwrite(os.path.join(frames_dir, f'frame_{i+1:02d}.jpg'), frame)
        print(f"   Frame {i+1}: t={t:.1f}s")
    
    cap.release()
    print(f"✅ Saved {num_frames} frames")


def generate_report(result, suspect_results, output_path, 
                   location_name="Unknown Location", location_address=""):
    """
    Generate JSON report for detected crime.
    
    Args:
        result: Crime detection result
        suspect_results: Suspect identification results
        output_path: Path to save report
        location_name: Location/building name
        location_address: Location address
    
    Returns:
        Report dictionary
    """
    # Determine if auto-send should trigger
    auto_send_threshold = 0.55
    confidence = result['max_score'] * 100
    
    # Determine severity
    if confidence >= 70:
        severity = "HIGH"
    elif confidence >= 50:
        severity = "MEDIUM"
    else:
        severity = "LOW"
    
    crime_type = "Unknown"
    if result['detections']:
        crime_type = result['detections'][0]['crime_type']
    
    # Build report
    report = {
        'report_id': f"CR-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        'generated_at': datetime.now().isoformat(),
        'auto_send': {
            'triggered': confidence >= auto_send_threshold * 100,
            'threshold': auto_send_threshold,
            'score': round(confidence, 1)
        },
        'crime': {
            'detected': result['is_anomalous'],
            'type': crime_type,
            'confidence': round(confidence, 1),
            'severity': severity
        },
        'time': {
            'start': suspect_results['crime_window']['start'] if suspect_results else None,
            'end': suspect_results['crime_window']['end'] if suspect_results else None,
            'duration': round(
                suspect_results['crime_window']['end'] - suspect_results['crime_window']['start'], 1
            ) if suspect_results else None
        },
        'location': {
            'name': location_name,
            'address': location_address,
            'camera': result.get('camera', 'Unknown')
        },
        'suspects': {
            'count': len(suspect_results.get('suspects', [])) if suspect_results else 0,
            'details': [
                {
                    'id': s['person_id'],
                    'score': s['suspicion_score'],
                    'reasons': s['reasons']
                }
                for s in suspect_results.get('suspects', [])[:5]
            ] if suspect_results else []
        },
        'evidence': suspect_results.get('evidence', {}) if suspect_results else {},
        'anomaly_scores': result['scores']
    }
    
    # Save report
    with open(output_path, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    print(f"📋 REPORT GENERATED")
    print(f"   Crime Type: {crime_type}")
    print(f"   Confidence: {confidence:.1f}%")
    print(f"   Auto-Send: {'✅ Triggered' if report['auto_send']['triggered'] else '❌ Not triggered'}")
    
    return report


def plot_anomaly_scores(result, output_path, threshold=0.45):
    """
    Plot anomaly scores.
    
    Args:
        result: Detection result
        output_path: Path to save plot
        threshold: Anomaly threshold
    """
    try:
        import matplotlib.pyplot as plt
        
        scores = result['scores']
        
        plt.figure(figsize=(14, 4))
        colors = ['red' if s > threshold else 'steelblue' for s in scores]
        plt.bar(range(len(scores)), scores, color=colors)
        plt.axhline(threshold, color='red', linestyle='--', label=f'Threshold ({threshold})')
        plt.xlabel('Segment')
        plt.ylabel('Anomaly Score')
        
        status = '🚨 ANOMALY DETECTED' if result['is_anomalous'] else 'Normal'
        plt.title(f"Crime Detection: {result['video_id']} - {status}")
        plt.legend()
        
        plt.savefig(output_path, dpi=150, bbox_inches='tight')
        plt.close()
        
        print(f"💾 Saved: {output_path}")
        
    except ImportError:
        print("⚠️ matplotlib not installed, skipping plot")


def print_results_summary(results):
    """
    Print summary table of detection results.
    
    Args:
        results: List of detection results
    """
    print(f"\n{'='*60}")
    print("📊 RESULTS SUMMARY")
    print(f"{'='*60}")
    print(f"{'Video':<30} {'Score':>8} {'Crime':<15} {'Status'}")
    print("-" * 60)
    
    for r in results:
        if 'error' in r:
            print(f"{os.path.basename(r.get('video_path', 'Unknown')):<30} {'ERROR':<8}")
            continue
        
        name = r.get('video_id', 'Unknown')[:28]
        score = f"{r['max_score']:.1%}"
        crime = r['detections'][0]['crime_type'] if r['detections'] else "-"
        status = "🚨" if r['is_anomalous'] else "✅"
        
        print(f"{name:<30} {score:>8} {crime:<15} {status}")
