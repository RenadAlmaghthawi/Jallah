"""
Loss functions for Crime Detection
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class MILRankingLoss(nn.Module):
    """
    Multiple Instance Learning Ranking Loss.
    
    Ensures max anomaly score in anomaly videos > max score in normal videos.
    Also includes smoothness and sparsity regularization.
    """
    
    def __init__(self, lam_smooth=8e-5, lam_sparse=8e-5):
        """
        Args:
            lam_smooth: Smoothness regularization weight
            lam_sparse: Sparsity regularization weight
        """
        super().__init__()
        self.lam_smooth = lam_smooth
        self.lam_sparse = lam_sparse
    
    def forward(self, norm_scores, anom_scores):
        """
        Compute MIL ranking loss.
        
        Args:
            norm_scores: Normal video scores (batch, segments) or (batch, segments, 1)
            anom_scores: Anomaly video scores (batch, segments) or (batch, segments, 1)
        
        Returns:
            Loss value
        """
        # Squeeze if needed
        if len(norm_scores.shape) == 3:
            norm_scores = norm_scores.squeeze(-1)
            anom_scores = anom_scores.squeeze(-1)
        
        loss = torch.tensor(0., device=norm_scores.device, requires_grad=True)
        
        for i in range(norm_scores.shape[0]):
            # Ranking loss: max(anomaly) > max(normal)
            loss = loss + F.relu(1. - anom_scores[i].max() + norm_scores[i].max())
            
            # Smoothness: penalize large changes between segments
            loss = loss + self.lam_smooth * ((anom_scores[i][:-1] - anom_scores[i][1:])**2).sum()
            
            # Sparsity: penalize too many high scores
            loss = loss + self.lam_sparse * anom_scores[i].sum()
        
        return loss / norm_scores.shape[0]


class CombinedLoss(nn.Module):
    """
    Combined loss for multi-task learning.
    
    Combines MIL ranking loss with classification cross-entropy.
    """
    
    def __init__(self, alpha=1.0, beta=1.0, lam_smooth=8e-5, lam_sparse=8e-5):
        """
        Args:
            alpha: Weight for MIL ranking loss
            beta: Weight for classification loss
            lam_smooth: Smoothness regularization weight
            lam_sparse: Sparsity regularization weight
        """
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.mil = MILRankingLoss(lam_smooth, lam_sparse)
        self.ce = nn.CrossEntropyLoss()
    
    def forward(self, n_anom, a_anom, n_cls, a_cls, a_labels):
        """
        Compute combined loss.
        
        Args:
            n_anom: Normal video anomaly scores
            a_anom: Anomaly video anomaly scores
            n_cls: Normal video class logits
            a_cls: Anomaly video class logits
            a_labels: Anomaly video labels
        
        Returns:
            Dictionary with total loss and components
        """
        # MIL ranking loss
        mil_loss = self.mil(n_anom.squeeze(-1), a_anom.squeeze(-1))
        
        # Classification loss (video-level pooling)
        n_vid = n_cls.mean(1)  # Average over segments
        a_vid = a_cls.mean(1)
        
        # Normal videos should be class 0
        n_labels = torch.zeros(n_vid.shape[0], dtype=torch.long, device=n_vid.device)
        
        ce_loss = (self.ce(n_vid, n_labels) + self.ce(a_vid, a_labels)) / 2
        
        return {
            'total': self.alpha * mil_loss + self.beta * ce_loss,
            'mil': mil_loss,
            'classification': ce_loss
        }
