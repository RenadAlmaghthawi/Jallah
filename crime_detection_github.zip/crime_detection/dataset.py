"""
Dataset classes for Crime Detection
"""

import os
import glob
import numpy as np
import torch
from torch.utils.data import Dataset


def process_feat(feat, length=32):
    """
    Process features to fixed length by temporal pooling.
    
    Args:
        feat: Input features (N, feature_dim)
        length: Target number of segments
    
    Returns:
        Processed features (length, feature_dim)
    """
    new_feat = np.zeros((length, feat.shape[1]), dtype=np.float32)
    r = np.linspace(0, len(feat), length + 1, dtype=np.int32)
    
    for i in range(length):
        if r[i] != r[i+1]:
            new_feat[i] = np.mean(feat[r[i]:r[i+1]], 0)
        else:
            new_feat[i] = feat[r[i]]
    
    return new_feat


def extract_base_name(fn):
    """Extract base video name without crop suffix."""
    name = fn.replace('.npy', '')
    for i in range(1, 10):
        name = name.replace(f'__{i}', '')
    return name


def get_crop_filename(base, idx):
    """Get crop filename for given index."""
    return f"{base}.npy" if idx == 0 else f"{base}__{idx}.npy"


class CrimeMILDataset(Dataset):
    """
    Multiple Instance Learning dataset for crime detection.
    
    Returns pairs of (normal, anomaly) samples for MIL training.
    """
    
    def __init__(self, features_dir, config, use_10crop=True):
        """
        Args:
            features_dir: Path to features directory
            config: Config object
            use_10crop: Whether to use 10-crop augmentation
        """
        self.config = config
        self.num_segments = config.num_segments
        self.normal_samples = []
        self.anomaly_samples = []
        
        # Load samples from each class directory
        for cls in config.classes:
            cdir = os.path.join(features_dir, cls)
            if not os.path.exists(cdir):
                continue
            
            files = glob.glob(os.path.join(cdir, '*.npy'))
            
            # Filter out crop files if not using 10-crop
            if not use_10crop:
                files = [f for f in files if '__' not in os.path.basename(f)]
            
            label_idx = config.get_class_idx(cls)
            
            for f in files:
                sample = {'path': f, 'label_idx': label_idx}
                if cls == 'Normal':
                    self.normal_samples.append(sample)
                else:
                    self.anomaly_samples.append(sample)
        
        print(f"MIL Dataset: {len(self.normal_samples)} normal, {len(self.anomaly_samples)} anomaly")
    
    def __len__(self):
        return max(len(self.normal_samples), len(self.anomaly_samples))
    
    def __getitem__(self, idx):
        # Random sample from each category
        ns = self.normal_samples[np.random.randint(len(self.normal_samples))]
        ans = self.anomaly_samples[np.random.randint(len(self.anomaly_samples))]
        
        # Load and process features
        nf = process_feat(np.load(ns['path']).astype(np.float32), self.num_segments)
        af = process_feat(np.load(ans['path']).astype(np.float32), self.num_segments)
        
        return torch.from_numpy(nf), torch.from_numpy(af), ans['label_idx']


class TestDataset(Dataset):
    """
    Test dataset for crime detection evaluation.
    
    Returns all crops for a video for averaging predictions.
    """
    
    def __init__(self, features_dir, config, return_all_crops=True):
        """
        Args:
            features_dir: Path to features directory
            config: Config object
            return_all_crops: Whether to return all crops or just first
        """
        self.config = config
        self.return_all_crops = return_all_crops
        self.videos = []
        
        # Group crop files by base video name
        for cls in os.listdir(features_dir):
            cdir = os.path.join(features_dir, cls)
            if not os.path.isdir(cdir):
                continue
            
            groups = {}
            for f in glob.glob(os.path.join(cdir, '*.npy')):
                bn = extract_base_name(os.path.basename(f))
                groups.setdefault(bn, []).append(f)
            
            label_idx = config.get_class_idx(cls) if cls in config.classes else -1
            
            for bn, paths in groups.items():
                # Sort crops by index
                paths.sort(key=lambda x: 0 if '__' not in x else int(x.split('__')[1].replace('.npy', '')))
                self.videos.append({
                    'base_name': bn,
                    'label_idx': label_idx,
                    'crop_paths': paths
                })
        
        print(f"Test Dataset: {len(self.videos)} videos")
    
    def __len__(self):
        return len(self.videos)
    
    def __getitem__(self, idx):
        v = self.videos[idx]
        
        if self.return_all_crops:
            # Stack all crops
            feats = [
                process_feat(np.load(p).astype(np.float32), self.config.num_segments)
                for p in v['crop_paths']
            ]
            return torch.from_numpy(np.stack(feats)), v['label_idx'], v['base_name']
        else:
            # Return only first crop
            feat = process_feat(
                np.load(v['crop_paths'][0]).astype(np.float32), 
                self.config.num_segments
            )
            return torch.from_numpy(feat), v['label_idx'], v['base_name']
