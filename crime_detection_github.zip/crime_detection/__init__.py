"""
Crime Detection System

A deep learning system for detecting and classifying crimes in surveillance videos.

Features:
- Multi-task learning (anomaly detection + crime classification)
- 7 crime types: Abuse, Assault, Burglary, Fighting, Robbery, Shoplifting, Stealing
- Suspect identification using YOLO
- Video clip extraction and evidence generation

Usage:
    from crime_detection import Config, CrimeDetector, I3DFeatureExtractor
    
    config = Config()
    detector = CrimeDetector('checkpoint.pth', config)
    result = detector.process(features_dir, video_name)
"""

from .config import Config
from .model import MultiTaskCrimeModel, load_pretrained_weights
from .dataset import CrimeMILDataset, TestDataset, process_feat
from .loss import MILRankingLoss, CombinedLoss
from .detector import CrimeDetector, Detection
from .feature_extractor import I3DFeatureExtractor
from .suspect_identifier import SuspectIdentifier

__version__ = '2.0.0'
__author__ = 'Johra'

__all__ = [
    'Config',
    'MultiTaskCrimeModel',
    'load_pretrained_weights',
    'CrimeMILDataset',
    'TestDataset',
    'process_feat',
    'MILRankingLoss',
    'CombinedLoss',
    'CrimeDetector',
    'Detection',
    'I3DFeatureExtractor',
    'SuspectIdentifier',
]
