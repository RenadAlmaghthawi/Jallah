"""
Training functions for Crime Detection
"""

import os
import torch
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
from tqdm import tqdm
from sklearn.metrics import roc_auc_score

from model import MultiTaskCrimeModel, load_pretrained_weights
from dataset import CrimeMILDataset, TestDataset
from loss import CombinedLoss


def train_epoch(model, loader, criterion, optimizer, device, epoch):
    """
    Train for one epoch.
    
    Args:
        model: Model to train
        loader: Training data loader
        criterion: Loss function
        optimizer: Optimizer
        device: Device to use
        epoch: Current epoch number
    
    Returns:
        Dictionary with loss values
    """
    model.train()
    total_loss, mil_loss, cls_loss = 0., 0., 0.
    n = 0
    
    for nf, af, al in tqdm(loader, desc=f"Epoch {epoch}"):
        nf, af, al = nf.to(device), af.to(device), al.to(device)
        
        # Forward pass
        na, nc = model(nf)
        aa, ac = model(af)
        
        # Compute loss
        losses = criterion(na, aa, nc, ac, al)
        
        # Backward pass
        optimizer.zero_grad()
        losses['total'].backward()
        optimizer.step()
        
        total_loss += losses['total'].item()
        mil_loss += losses['mil'].item()
        cls_loss += losses['classification'].item()
        n += 1
    
    return {
        'total': total_loss / n,
        'mil': mil_loss / n,
        'classification': cls_loss / n
    }


def evaluate(model, loader, device, config):
    """
    Evaluate model on test set.
    
    Args:
        model: Model to evaluate
        loader: Test data loader
        device: Device to use
        config: Config object
    
    Returns:
        Dictionary with metrics
    """
    model.eval()
    predictions = []
    labels = []
    scores = []
    
    with torch.no_grad():
        for feats, label_idx, _ in tqdm(loader, desc="Eval"):
            feats = feats.to(device)
            
            # Handle multi-crop
            if len(feats.shape) == 4:
                crop_a, crop_c = [], []
                for ci in range(feats.shape[1]):
                    a, c = model(feats[0, ci].unsqueeze(0))
                    crop_a.append(a.squeeze(0))
                    crop_c.append(c.squeeze(0))
                avg_a = torch.stack(crop_a).mean(0)
                avg_c = torch.stack(crop_c).mean(0)
            else:
                avg_a, avg_c = model(feats)
                avg_a = avg_a.squeeze(0)
                avg_c = avg_c.squeeze(0)
            
            # Get prediction
            result = model.get_video_prediction(avg_a, avg_c, config.anomaly_threshold)
            
            predictions.append(result['predicted_class_idx'])
            labels.append(label_idx.item())
            scores.append(result['max_anomaly_score'])
    
    predictions = np.array(predictions)
    labels = np.array(labels)
    scores = np.array(scores)
    
    # Compute metrics
    accuracy = (predictions == labels).mean()
    
    try:
        # AUC: binary (anomaly vs normal)
        auc = roc_auc_score((labels != 0).astype(int), scores)
    except:
        auc = 0.
    
    return {'accuracy': accuracy, 'auc': auc}


def train_model(config, checkpoint_name='latest_checkpoint_v2.pth', max_epochs=None):
    """
    Main training function with auto-resume.
    
    Args:
        config: Config object
        checkpoint_name: Name for checkpoint files
        max_epochs: Maximum epochs to train (default from config)
    
    Returns:
        Trained model and training history
    """
    max_epochs = max_epochs or config.max_epochs
    device = torch.device(config.device if torch.cuda.is_available() else 'cpu')
    save_dir = config.checkpoints_dir
    
    print(f"Device: {device}")
    print(f"💾 Checkpoints save to: {save_dir}")
    
    # Check for existing checkpoint
    latest_ckpt = os.path.join(save_dir, checkpoint_name)
    resume = os.path.exists(latest_ckpt)
    
    # Create model
    model = MultiTaskCrimeModel(
        config.feature_size, 
        config.n_classes, 
        config.dropout_rate
    )
    
    # Load pretrained if not resuming
    if not resume and os.path.exists(config.pretrained_checkpoint):
        model = load_pretrained_weights(model, config.pretrained_checkpoint)
    
    model = model.to(device)
    
    # Create datasets
    print("\nLoading datasets...")
    train_ds = CrimeMILDataset(config.train_features_dir, config, config.use_10crop_train)
    test_ds = TestDataset(config.test_features_dir, config, config.use_10crop_test)
    
    train_loader = DataLoader(
        train_ds, config.batch_size, shuffle=True,
        num_workers=config.num_workers, pin_memory=True, drop_last=True
    )
    test_loader = DataLoader(
        test_ds, 1, shuffle=False,
        num_workers=config.num_workers, pin_memory=True
    )
    
    # Setup optimizer
    criterion = CombinedLoss(
        config.anomaly_loss_weight,
        config.classification_loss_weight,
        config.lambda_smooth,
        config.lambda_sparse
    )
    
    optimizer = optim.Adam(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay
    )
    
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=max_epochs, eta_min=1e-6
    )
    
    history = {'train_loss': [], 'val_accuracy': [], 'val_auc': []}
    best_auc = 0.
    start_epoch = 0
    
    # Resume if checkpoint exists
    if resume:
        print(f"\n🔄 RESUMING from {latest_ckpt}")
        ckpt = torch.load(latest_ckpt, map_location=device, weights_only=False)
        model.load_state_dict(ckpt['model_state_dict'])
        optimizer.load_state_dict(ckpt['optimizer_state_dict'])
        scheduler.load_state_dict(ckpt['scheduler_state_dict'])
        start_epoch = ckpt['epoch'] + 1
        best_auc = ckpt.get('best_auc', ckpt.get('best_accuracy', 0.))
        history = ckpt.get('history', history)
        print(f"   Continuing from epoch {start_epoch}, best AUC: {best_auc:.4f}")
    
    print(f"\n{'='*50}")
    print(f"Training epochs {start_epoch} to {max_epochs-1}")
    print(f"{'='*50}")
    
    # Training loop
    for epoch in range(start_epoch, max_epochs):
        train_loss = train_epoch(model, train_loader, criterion, optimizer, device, epoch)
        scheduler.step()
        
        # Evaluate
        metrics = evaluate(model, test_loader, device, config)
        
        print(f"\nEpoch {epoch}: Loss={train_loss['total']:.4f}, "
              f"Acc={metrics['accuracy']:.4f}, AUC={metrics['auc']:.4f}")
        
        # Update history
        history['train_loss'].append(train_loss['total'])
        history['val_accuracy'].append(metrics['accuracy'])
        history['val_auc'].append(metrics['auc'])
        
        # Save checkpoint
        ckpt_data = {
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            'scheduler_state_dict': scheduler.state_dict(),
            'best_auc': best_auc,
            'best_accuracy': metrics['accuracy'],
            'history': history
        }
        
        torch.save(ckpt_data, latest_ckpt)
        print(f"  💾 Saved checkpoint (epoch {epoch})")
        
        # Save best model
        if metrics['auc'] > best_auc:
            best_auc = metrics['auc']
            ckpt_data['best_auc'] = best_auc
            best_path = os.path.join(save_dir, checkpoint_name.replace('latest_', 'best_'))
            torch.save(ckpt_data, best_path)
            print(f"  🏆 New best! AUC={best_auc:.4f}")
    
    # Save final model
    torch.save(model.state_dict(), os.path.join(save_dir, 'final_model.pth'))
    
    print(f"\n{'='*50}")
    print(f"✅ Done! Best AUC: {best_auc:.4f}")
    print(f"{'='*50}")
    
    return model, history


if __name__ == '__main__':
    from config import Config
    
    config = Config()
    model, history = train_model(config, max_epochs=100)
