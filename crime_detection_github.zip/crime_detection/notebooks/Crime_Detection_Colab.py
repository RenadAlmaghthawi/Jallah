# ---
# jupyter:
#   jupytext:
#     text_representation:
#       extension: .py
#       format_name: percent
#   kernelspec:
#     display_name: Python 3
#     name: python3
# ---

# %% [markdown]
# # 🚨 Crime Detection System
# 
# **Features:** Anomaly Detection + Crime Classification (7 types) + Suspect Identification
# 
# ⚠️ **Checkpoints save to Google Drive** - safe from runtime resets!

# %% [markdown]
# ## 1️⃣ Setup

# %%
# Install dependencies
!pip install -q torch torchvision tqdm scikit-learn ultralytics opencv-python

import torch
print(f"PyTorch: {torch.__version__}, CUDA: {torch.cuda.is_available()}")
if torch.cuda.is_available():
    print(f"GPU: {torch.cuda.get_device_name(0)}")

# %%
# Mount Google Drive
from google.colab import drive
drive.mount('/content/drive')

# ⚠️ UPDATE THIS PATH!
BASE_PATH = '/content/drive/MyDrive/DeepMIL'

import os
print(f"Base path exists: {os.path.exists(BASE_PATH)}")

# %% [markdown]
# ## 2️⃣ Clone Repository (or upload files)

# %%
# Option 1: Clone from GitHub
# !git clone https://github.com/yourusername/crime-detection.git
# %cd crime-detection

# Option 2: Upload files manually and add to path
import sys
sys.path.append('/content/drive/MyDrive/DeepMIL/crime_detection')

# %% [markdown]
# ## 3️⃣ Configuration

# %%
from config import Config

# ⚠️ UPDATE PATH!
config = Config(base_path='/content/drive/MyDrive/DeepMIL')
config.anomaly_threshold = 0.45
config.min_anomaly_duration = 1

print(f"Train: {config.train_features_dir}")
print(f"Test: {config.test_features_dir}")
print(f"Checkpoints: {config.checkpoints_dir}")

# %% [markdown]
# ## 4️⃣ Training

# %%
from trainer import train_model

# Check paths
print("Checking paths...")
print(f"  Train: {os.path.exists(config.train_features_dir)}")
print(f"  Test: {os.path.exists(config.test_features_dir)}")
print(f"  Pretrained: {os.path.exists(config.pretrained_checkpoint)}")

# Train (auto-resumes if checkpoint exists)
model, history = train_model(
    config, 
    checkpoint_name='latest_checkpoint_v2.pth',
    max_epochs=100
)

# %% [markdown]
# ## 5️⃣ Plot Training History

# %%
import matplotlib.pyplot as plt

fig, axes = plt.subplots(1, 3, figsize=(15, 4))

# Loss
axes[0].plot(history['train_loss'])
axes[0].set_title('Training Loss')
axes[0].set_xlabel('Epoch')
axes[0].set_ylabel('Loss')

# Accuracy
axes[1].plot(history['val_accuracy'])
axes[1].set_title('Validation Accuracy')
axes[1].set_xlabel('Epoch')
axes[1].set_ylabel('Accuracy')

# AUC
axes[2].plot(history['val_auc'])
axes[2].set_title('Validation AUC')
axes[2].set_xlabel('Epoch')
axes[2].set_ylabel('AUC')

plt.tight_layout()
plt.savefig(f'{config.output_dir}/training_history.png', dpi=150)
plt.show()

print(f"Best Accuracy: {max(history['val_accuracy']):.4f}")
print(f"Best AUC: {max(history['val_auc']):.4f}")

# %% [markdown]
# ## 6️⃣ Inference

# %%
from detector import CrimeDetector
import json

# Load detector
detector = CrimeDetector(
    os.path.join(config.checkpoints_dir, 'best_model_v2.pth'),
    config
)

# %%
# Test on a video from the dataset
result = detector.process(
    fdir=os.path.join(config.test_features_dir, 'Burglary'),
    vname='Burglary035_x264',
    camera='Test Camera',
    total_frames=4050,
    fps=30
)

print(json.dumps(result, indent=2))

# %% [markdown]
# ## 7️⃣ Process Custom Videos

# %%
from feature_extractor import I3DFeatureExtractor, pad_features
import numpy as np

# Initialize extractor
extractor = I3DFeatureExtractor(device='cuda')

# %%
# Process a video
VIDEO_PATH = '/content/drive/MyDrive/DeepMIL/Videos/videoplayback.mp4'
OUTPUT_DIR = '/content/drive/MyDrive/DeepMIL/demo_output'
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Extract features
features, total_frames, fps = extractor.extract(VIDEO_PATH, num_segments=32)

# Pad to 1024 if needed
if features.shape[1] != 1024:
    features = pad_features(features, 1024)

# Run detection
result = detector.process_features(
    features=features,
    video_id=os.path.basename(VIDEO_PATH),
    camera='YouTube Video',
    total_frames=total_frames,
    fps=int(fps)
)

print(f"\n🎯 Result: {result['max_score']:.1%}")
if result['detections']:
    print(f"   Crime: {result['detections'][0]['crime_type']}")

# %% [markdown]
# ## 8️⃣ Suspect Identification

# %%
from suspect_identifier import SuspectIdentifier

if result['is_anomalous']:
    identifier = SuspectIdentifier(
        anomaly_result=result,
        video_path=VIDEO_PATH,
        threshold=config.anomaly_threshold,
        output_dir=OUTPUT_DIR
    )
    
    suspect_results = identifier.run(
        buffer_before=30,
        buffer_after=15,
        sample_fps=2.0
    )
    
    print(f"\n📊 Found {len(suspect_results['suspects'])} suspects")

# %% [markdown]
# ## 9️⃣ Generate Report

# %%
from utils import generate_report, extract_crime_clip, plot_anomaly_scores

# Plot anomaly scores
plot_anomaly_scores(result, f'{OUTPUT_DIR}/anomaly_scores.png', config.anomaly_threshold)

# Generate report
if result['is_anomalous'] and 'suspect_results' in dir():
    report = generate_report(
        result, 
        suspect_results,
        f'{OUTPUT_DIR}/report.json',
        location_name='Surveillance Camera 1'
    )
    
    # Extract crime clip
    extract_crime_clip(
        VIDEO_PATH,
        suspect_results['crime_window']['start'],
        suspect_results['crime_window']['end'],
        f'{OUTPUT_DIR}/crime_clip.mp4',
        buffer=30
    )

print(f"\n✅ Output saved to: {OUTPUT_DIR}")

# %% [markdown]
# ## 🔟 Batch Processing

# %%
from utils import print_results_summary

# Get all videos
VIDEO_FOLDER = '/content/drive/MyDrive/DeepMIL/Videos'
video_paths = [
    os.path.join(VIDEO_FOLDER, f) 
    for f in os.listdir(VIDEO_FOLDER) 
    if f.endswith(('.mp4', '.avi'))
]

print(f"Found {len(video_paths)} videos")

# Process all
results = []
for video_path in video_paths[:5]:  # Limit to 5 for demo
    try:
        # Extract features
        features, total_frames, fps = extractor.extract(video_path, num_segments=32)
        if features.shape[1] != 1024:
            features = pad_features(features, 1024)
        
        # Run detection
        result = detector.process_features(
            features=features,
            video_id=os.path.basename(video_path),
            camera='Batch',
            total_frames=total_frames,
            fps=int(fps)
        )
        results.append(result)
        
        status = "🚨 CRIME" if result['is_anomalous'] else "✅ Normal"
        crime = result['detections'][0]['crime_type'] if result['detections'] else "-"
        print(f"{os.path.basename(video_path)}: {result['max_score']:.1%} {crime} {status}")
        
    except Exception as e:
        print(f"❌ {os.path.basename(video_path)}: {e}")

# Summary
print_results_summary(results)

# %% [markdown]
# ## ✅ Done!
# 
# Output files:
# - `training_history.png` - Training curves
# - `anomaly_scores.png` - Per-segment scores
# - `crime_clip.mp4` - Extracted crime footage
# - `report.json` - Detection report
# - `suspects/` - Suspect images
