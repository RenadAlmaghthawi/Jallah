# 🚨 Crime Detection System

A deep learning system for detecting and classifying crimes in surveillance videos using Multiple Instance Learning (MIL).

![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)
![PyTorch](https://img.shields.io/badge/PyTorch-2.0+-red.svg)
![License](https://img.shields.io/badge/License-MIT-green.svg)

## 📋 Features

- **Multi-task Learning**: Simultaneous anomaly detection and crime classification
- **7 Crime Types**: Abuse, Assault, Burglary, Fighting, Robbery, Shoplifting, Stealing
- **High Accuracy**: 91.6% AUC on UCF-Crime dataset
- **Suspect Identification**: Automatic person tracking using YOLOv8
- **Evidence Generation**: Video clips, key frames, and detailed reports
- **Auto-Resume Training**: Checkpoints saved to Google Drive

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Crime Detection Pipeline                  │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  📹 Video Input                                              │
│       ↓                                                      │
│  🎯 I3D Feature Extraction (1024-dim per segment)           │
│       ↓                                                      │
│  🧠 DeepMIL Model                                           │
│       ├── Anomaly Head → Anomaly Score (0-1)                │
│       └── Classification Head → Crime Type                   │
│       ↓                                                      │
│  🕵️ Suspect Identification (YOLOv8)                         │
│       ↓                                                      │
│  📋 Report Generation                                        │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## 📁 Project Structure

```
crime_detection/
├── __init__.py           # Package initialization
├── config.py             # Configuration dataclass
├── model.py              # DeepMIL model architecture
├── dataset.py            # Dataset classes for training/testing
├── loss.py               # MIL ranking loss and combined loss
├── trainer.py            # Training functions with auto-resume
├── detector.py           # Crime detection inference
├── feature_extractor.py  # I3D feature extraction from videos
├── suspect_identifier.py # Suspect identification using YOLO
├── utils.py              # Utility functions
├── inference.py          # Main inference script
└── notebooks/
    └── Crime_Detection_Colab.ipynb  # Google Colab notebook
```

## 🚀 Quick Start

### Installation

```bash
# Clone repository
git clone https://github.com/yourusername/crime-detection.git
cd crime-detection

# Install dependencies
pip install torch torchvision tqdm scikit-learn ultralytics opencv-python
```

### Inference

```bash
# Process a single video
python inference.py --video path/to/video.mp4 --checkpoint checkpoints/best_model_v2.pth

# Process multiple videos
python inference.py --video path/to/videos/ --checkpoint checkpoints/best_model_v2.pth --output results/
```

### Training

```python
from crime_detection import Config
from crime_detection.trainer import train_model

# Configure
config = Config(base_path='/path/to/data')
config.max_epochs = 100
config.learning_rate = 0.00005

# Train (auto-resumes if checkpoint exists)
model, history = train_model(config)
```

## 📊 Dataset

Trained on [UCF-Crime Dataset](https://www.crcv.ucf.edu/projects/real-world/):

| Type | Videos | Duration |
|------|--------|----------|
| Training (Normal) | 800 | - |
| Training (Anomaly) | 810 | - |
| Testing (Normal) | 150 | - |
| Testing (Anomaly) | 140 | - |
| **Total** | **1,900** | **128 hours** |

### Crime Categories

| Crime Type | Description |
|------------|-------------|
| Abuse | Physical abuse |
| Assault | Physical attack |
| Burglary | Breaking and entering |
| Fighting | Physical altercation |
| Robbery | Theft with force |
| Shoplifting | Store theft |
| Stealing | General theft |

## 📈 Performance

| Metric | Score |
|--------|-------|
| AUC | 91.6% |
| Accuracy | 78.5% |
| Detection Threshold | 0.45 |

### Threshold Analysis

| Threshold | Accuracy | Recall | Precision |
|-----------|----------|--------|-----------|
| 0.60 | 77.5% | 65.0% | 83.2% |
| 0.50 | 80.2% | 75.3% | 79.1% |
| **0.45** | **81.5%** | **78.6%** | **77.3%** |
| 0.40 | 79.8% | 82.1% | 72.4% |

## 🔧 Configuration

```python
@dataclass
class Config:
    # Model
    feature_size: int = 1024
    n_classes: int = 8
    dropout_rate: float = 0.6
    
    # Training
    batch_size: int = 32
    num_segments: int = 32
    learning_rate: float = 0.00005
    max_epochs: int = 100
    
    # Detection
    anomaly_threshold: float = 0.45
    min_anomaly_duration: int = 2
```

## 📝 Output Format

### Detection Result

```json
{
  "video_id": "video_name",
  "is_anomalous": true,
  "max_score": 0.876,
  "detections": [
    {
      "crime_type": "Burglary",
      "confidence": 0.82,
      "start_time": "0:02:15",
      "end_time": "0:02:45",
      "anomaly_score": 0.876
    }
  ],
  "scores": [0.12, 0.15, ..., 0.87, 0.65]
}
```

### Suspect Report

```json
{
  "report_id": "CR-20251212090308",
  "crime": {
    "type": "Burglary",
    "confidence": 87.6,
    "severity": "HIGH"
  },
  "suspects": {
    "count": 2,
    "details": [...]
  }
}
```

## 🛠️ Technologies

- **PyTorch 2.0** - Deep learning framework
- **I3D** - Video feature extraction
- **YOLOv8** - Object detection
- **OpenCV** - Video processing
- **NumPy/Pandas** - Data processing

## 📚 References

- [Real-world Anomaly Detection in Surveillance Videos](https://arxiv.org/abs/1801.04264)
- [UCF-Crime Dataset](https://www.crcv.ucf.edu/projects/real-world/)
- [Multiple Instance Learning](https://en.wikipedia.org/wiki/Multiple_instance_learning)

## 📄 License

MIT License - see [LICENSE](LICENSE) for details.

## 👤 Author

**Johra** - Physics graduate with AI/ML specialization

---

⭐ Star this repo if you find it helpful!
