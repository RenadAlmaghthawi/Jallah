"""
I3D Feature Extractor for raw video files
"""

import os
import cv2
import numpy as np
import torch
import torch.nn as nn
from torchvision import models, transforms


class I3DFeatureExtractor:
    """
    Extract I3D features from video files.
    
    Uses pretrained I3D model to extract spatiotemporal features.
    """
    
    def __init__(self, device='cuda'):
        """
        Initialize extractor.
        
        Args:
            device: Device to use ('cuda' or 'cpu')
        """
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Use R3D-18 as I3D backbone (similar performance, easier to load)
        print("Loading I3D model...")
        self.model = models.video.r3d_18(pretrained=True)
        
        # Remove classification head to get features
        self.model.fc = nn.Identity()
        self.model = self.model.to(self.device)
        self.model.eval()
        
        # Preprocessing
        self.transform = transforms.Compose([
            transforms.ToPILImage(),
            transforms.Resize((112, 112)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.43216, 0.394666, 0.37645],
                std=[0.22803, 0.22145, 0.216989]
            )
        ])
        
        print(f"✅ I3D Extractor ready on {self.device}")
    
    def extract(self, video_path, num_segments=32, frames_per_segment=16):
        """
        Extract features from video.
        
        Args:
            video_path: Path to video file
            num_segments: Number of segments to extract
            frames_per_segment: Frames per segment
        
        Returns:
            features: Numpy array of shape (num_segments, 512)
            total_frames: Total frames in video
            fps: Video FPS
        """
        # Open video
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise ValueError(f"Cannot open video: {video_path}")
        
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        duration = total_frames / fps
        
        print(f"🎬 Processing: {os.path.basename(video_path)}")
        print(f"   Frames: {total_frames}, FPS: {fps:.1f}, Duration: {duration:.1f}s")
        
        # Calculate segment boundaries
        segment_length = total_frames // num_segments
        
        features = []
        
        for seg_idx in range(num_segments):
            start_frame = seg_idx * segment_length
            
            # Read frames for this segment
            frames = []
            cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            
            for _ in range(frames_per_segment):
                ret, frame = cap.read()
                if not ret:
                    # Repeat last frame if video ends
                    if frames:
                        frames.append(frames[-1])
                    continue
                
                # Convert BGR to RGB
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frames.append(self.transform(frame))
            
            # Ensure we have enough frames
            while len(frames) < frames_per_segment:
                frames.append(frames[-1] if frames else torch.zeros(3, 112, 112))
            
            # Stack and extract features
            clip = torch.stack(frames[:frames_per_segment])  # (T, C, H, W)
            clip = clip.permute(1, 0, 2, 3).unsqueeze(0)  # (1, C, T, H, W)
            clip = clip.to(self.device)
            
            with torch.no_grad():
                feat = self.model(clip)
            
            features.append(feat.cpu().numpy().squeeze())
            
            if (seg_idx + 1) % 8 == 0:
                print(f"   Segment {seg_idx + 1}/{num_segments}")
        
        cap.release()
        
        features = np.array(features)
        print(f"✅ Features: {features.shape}")
        
        return features, total_frames, fps
    
    def extract_batch(self, video_paths, output_dir, num_segments=32):
        """
        Extract features from multiple videos.
        
        Args:
            video_paths: List of video paths
            output_dir: Directory to save features
            num_segments: Number of segments per video
        
        Returns:
            List of result dictionaries
        """
        os.makedirs(output_dir, exist_ok=True)
        results = []
        
        for i, video_path in enumerate(video_paths):
            print(f"\n[{i+1}/{len(video_paths)}] {os.path.basename(video_path)}")
            
            try:
                features, total_frames, fps = self.extract(video_path, num_segments)
                
                # Save features
                video_name = os.path.splitext(os.path.basename(video_path))[0]
                feat_path = os.path.join(output_dir, f"{video_name}.npy")
                np.save(feat_path, features)
                
                results.append({
                    'video_path': video_path,
                    'features_path': feat_path,
                    'total_frames': total_frames,
                    'fps': fps,
                    'success': True
                })
                
            except Exception as e:
                print(f"   ❌ Error: {e}")
                results.append({
                    'video_path': video_path,
                    'error': str(e),
                    'success': False
                })
        
        return results


# Pad features to target size if needed
def pad_features(features, target_dim=1024):
    """
    Pad features to target dimension.
    
    Args:
        features: Input features (N, D)
        target_dim: Target feature dimension
    
    Returns:
        Padded features (N, target_dim)
    """
    if features.shape[1] >= target_dim:
        return features[:, :target_dim]
    
    pad_size = target_dim - features.shape[1]
    padding = np.zeros((features.shape[0], pad_size), dtype=features.dtype)
    return np.concatenate([features, padding], axis=1)
