"""
Inference script for Crime Detection System

Usage:
    python inference.py --video path/to/video.mp4 --checkpoint path/to/model.pth
"""

import os
import argparse
import json
import numpy as np

from config import Config
from detector import CrimeDetector
from feature_extractor import I3DFeatureExtractor, pad_features
from suspect_identifier import SuspectIdentifier
from utils import (
    extract_crime_clip, extract_key_frames,
    generate_report, plot_anomaly_scores, print_results_summary
)


def process_video(video_path, detector, extractor, config, output_dir):
    """
    Process a single video: extract features, detect crime, identify suspects.
    
    Args:
        video_path: Path to video file
        detector: CrimeDetector instance
        extractor: I3DFeatureExtractor instance
        config: Config object
        output_dir: Output directory
    
    Returns:
        Result dictionary
    """
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    video_output_dir = os.path.join(output_dir, video_name)
    os.makedirs(video_output_dir, exist_ok=True)
    
    print(f"\n{'='*60}")
    print(f"🎬 Processing: {video_name}")
    print(f"{'='*60}")
    
    # Extract features
    features, total_frames, fps = extractor.extract(video_path, num_segments=32)
    
    # Pad features to 1024 if needed
    if features.shape[1] != 1024:
        features = pad_features(features, 1024)
    
    # Save features
    feat_path = os.path.join(video_output_dir, f'{video_name}_features.npy')
    np.save(feat_path, features)
    
    # Run detection
    result = detector.process_features(
        features=features,
        video_id=video_name,
        camera='Video Analysis',
        total_frames=total_frames,
        fps=int(fps)
    )
    
    # Print detection result
    print(f"\n🔍 Detection Result:")
    print(f"   Anomaly Score: {result['max_score']:.1%}")
    print(f"   Is Anomalous: {result['is_anomalous']}")
    
    if result['detections']:
        det = result['detections'][0]
        print(f"   Crime Type: {det['crime_type']}")
        print(f"   Confidence: {det['confidence']:.1%}")
        print(f"   Time: {det['start_time']} - {det['end_time']}")
    
    # Save detection result
    result_path = os.path.join(video_output_dir, 'detection_result.json')
    with open(result_path, 'w') as f:
        json.dump(result, f, indent=2)
    
    # Plot anomaly scores
    plot_path = os.path.join(video_output_dir, 'anomaly_scores.png')
    plot_anomaly_scores(result, plot_path, config.anomaly_threshold)
    
    # If crime detected, run suspect identification
    suspect_results = None
    if result['is_anomalous']:
        print(f"\n🕵️ Running Suspect Identification...")
        
        identifier = SuspectIdentifier(
            anomaly_result=result,
            video_path=video_path,
            threshold=config.anomaly_threshold,
            output_dir=video_output_dir
        )
        
        suspect_results = identifier.run(
            buffer_before=30,
            buffer_after=15,
            sample_fps=2.0
        )
        
        # Save suspect results
        suspect_path = os.path.join(video_output_dir, 'suspect_results.json')
        with open(suspect_path, 'w') as f:
            json.dump(suspect_results, f, indent=2, default=str)
        
        # Extract crime clip
        if suspect_results.get('crime_window'):
            clip_path = os.path.join(video_output_dir, 'crime_clip.mp4')
            extract_crime_clip(
                video_path,
                suspect_results['crime_window']['start'],
                suspect_results['crime_window']['end'],
                clip_path,
                buffer=30
            )
            
            # Extract key frames
            extract_key_frames(
                video_path,
                suspect_results['crime_window']['start'],
                suspect_results['crime_window']['end'],
                video_output_dir,
                num_frames=6
            )
        
        # Generate report
        report_path = os.path.join(video_output_dir, 'report.json')
        generate_report(result, suspect_results, report_path)
    
    return {
        'video_path': video_path,
        'result': result,
        'suspect_results': suspect_results,
        'output_dir': video_output_dir
    }


def main():
    parser = argparse.ArgumentParser(description='Crime Detection Inference')
    parser.add_argument('--video', type=str, required=True,
                       help='Path to video file or directory')
    parser.add_argument('--checkpoint', type=str, required=True,
                       help='Path to model checkpoint')
    parser.add_argument('--output', type=str, default='./output',
                       help='Output directory')
    parser.add_argument('--threshold', type=float, default=0.45,
                       help='Anomaly detection threshold')
    parser.add_argument('--device', type=str, default='cuda',
                       help='Device to use (cuda/cpu)')
    
    args = parser.parse_args()
    
    # Setup config
    config = Config()
    config.anomaly_threshold = args.threshold
    config.device = args.device
    
    # Initialize models
    print("Initializing models...")
    extractor = I3DFeatureExtractor(device=args.device)
    detector = CrimeDetector(args.checkpoint, config)
    
    # Get video paths
    if os.path.isdir(args.video):
        video_paths = [
            os.path.join(args.video, f)
            for f in os.listdir(args.video)
            if f.endswith(('.mp4', '.avi', '.mkv'))
        ]
    else:
        video_paths = [args.video]
    
    print(f"\nFound {len(video_paths)} video(s)")
    
    # Process videos
    os.makedirs(args.output, exist_ok=True)
    results = []
    
    for video_path in video_paths:
        try:
            result = process_video(
                video_path, detector, extractor, config, args.output
            )
            results.append(result['result'])
        except Exception as e:
            print(f"❌ Error processing {video_path}: {e}")
            results.append({'video_path': video_path, 'error': str(e)})
    
    # Print summary
    print_results_summary(results)
    
    # Save all results
    all_results_path = os.path.join(args.output, 'all_results.json')
    with open(all_results_path, 'w') as f:
        json.dump(results, f, indent=2, default=str)
    
    print(f"\n✅ Done! Results saved to: {args.output}")


if __name__ == '__main__':
    main()
