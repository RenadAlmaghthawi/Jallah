"""
Crime Detector - Inference module for crime detection
"""

import os
import torch
import numpy as np
from datetime import timedelta
from dataclasses import dataclass, asdict

from model import MultiTaskCrimeModel
from dataset import process_feat, get_crop_filename


@dataclass
class Detection:
    """Detection result for a crime segment."""
    crime_type: str
    confidence: float
    start_time: str
    end_time: str
    start_frame: int
    end_frame: int
    anomaly_score: float
    all_probabilities: dict


class CrimeDetector:
    """
    Crime detection inference class.
    
    Loads trained model and runs inference on video features.
    """
    
    def __init__(self, checkpoint_path, config):
        """
        Initialize detector.
        
        Args:
            checkpoint_path: Path to model checkpoint
            config: Config object
        """
        self.config = config
        self.device = torch.device(config.device if torch.cuda.is_available() else 'cpu')
        
        # Load model
        self.model = MultiTaskCrimeModel(
            config.feature_size,
            config.n_classes,
            config.dropout_rate
        )
        
        ckpt = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        sd = ckpt.get('model_state_dict', ckpt)
        self.model.load_state_dict({k.replace('module.', ''): v for k, v in sd.items()})
        self.model.to(self.device).eval()
        
        print(f"Detector ready on {self.device}")
    
    def load_features(self, fdir, vname):
        """
        Load features for a video (all crops).
        
        Args:
            fdir: Features directory
            vname: Video name
        
        Returns:
            Tensor of shape (num_crops, num_segments, feature_size)
        """
        feats = []
        for i in range(10):
            fp = os.path.join(fdir, get_crop_filename(vname, i))
            if os.path.exists(fp):
                feats.append(process_feat(
                    np.load(fp).astype(np.float32),
                    self.config.num_segments
                ))
        return torch.from_numpy(np.stack(feats))
    
    @torch.no_grad()
    def predict(self, feats):
        """
        Run prediction on features.
        
        Args:
            feats: Feature tensor (num_crops, num_segments, feature_size)
        
        Returns:
            scores: Anomaly scores per segment
            logits: Class logits per segment
            pred: Video-level prediction dictionary
        """
        feats = feats.to(self.device)
        
        crop_a, crop_c = [], []
        for i in range(feats.shape[0]):
            a, c = self.model(feats[i].unsqueeze(0))
            crop_a.append(a.squeeze(0))
            crop_c.append(c.squeeze(0))
        
        avg_a = torch.stack(crop_a).mean(0)
        avg_c = torch.stack(crop_c).mean(0)
        
        scores = avg_a.cpu().numpy().squeeze()
        logits = avg_c.cpu().numpy()
        pred = self.model.get_video_prediction(
            avg_a, avg_c, 
            threshold=self.config.anomaly_threshold
        )
        
        return scores, logits, pred
    
    def process(self, fdir, vname, camera='Unknown', total_frames=None, fps=30):
        """
        Process a video and detect crimes.
        
        Args:
            fdir: Features directory containing the video features
            vname: Video name (without extension)
            camera: Camera name/location
            total_frames: Total frames in video
            fps: Frames per second
        
        Returns:
            Dictionary with detection results
        """
        total_frames = total_frames or self.config.num_segments * self.config.frames_per_segment
        
        # Load and predict
        feats = self.load_features(fdir, vname)
        scores, logits, pred = self.predict(feats)
        
        # Find continuous anomaly segments
        detections = []
        above = scores > self.config.anomaly_threshold
        start = None
        
        for i, a in enumerate(above):
            if a and start is None:
                start = i
            elif not a and start is not None:
                # Check minimum duration
                if i - start >= self.config.min_anomaly_duration:
                    det = self._create_detection(
                        start, i, scores, logits, 
                        total_frames, fps
                    )
                    detections.append(det)
                start = None
        
        # Handle anomaly at end of video
        if start is not None and len(above) - start >= self.config.min_anomaly_duration:
            det = self._create_detection(
                start, len(above), scores, logits,
                total_frames, fps
            )
            detections.append(det)
        
        return {
            'video_id': vname,
            'camera': camera,
            'is_anomalous': pred['is_anomaly'],
            'max_score': pred['max_anomaly_score'],
            'detections': [asdict(d) for d in detections],
            'scores': scores.tolist()
        }
    
    def _create_detection(self, start, end, scores, logits, total_frames, fps):
        """Create a Detection object for a segment."""
        sf = int(start * total_frames / self.config.num_segments)
        ef = int(end * total_frames / self.config.num_segments)
        
        # Average logits in segment
        sl = logits[start:end].mean(0)
        probs = torch.softmax(torch.from_numpy(sl), 0).numpy()
        
        crime_idx = np.argmax(probs)
        crime_type = self.config.classes[crime_idx]
        
        all_probs = {
            self.config.classes[j]: float(probs[j])
            for j in range(self.config.n_classes)
        }
        
        return Detection(
            crime_type=crime_type,
            confidence=float(probs[crime_idx]),
            start_time=str(timedelta(seconds=sf // fps)),
            end_time=str(timedelta(seconds=ef // fps)),
            start_frame=sf,
            end_frame=ef,
            anomaly_score=float(scores[start:end].max()),
            all_probabilities=all_probs
        )
    
    def process_features(self, features, video_id, camera='YouTube', total_frames=None, fps=30):
        """
        Process pre-extracted features (for custom videos).
        
        Args:
            features: Numpy array of shape (num_segments, feature_size)
            video_id: Video identifier
            camera: Camera name
            total_frames: Total frames in video
            fps: Frames per second
        
        Returns:
            Dictionary with detection results
        """
        total_frames = total_frames or self.config.num_segments * self.config.frames_per_segment
        
        # Convert to tensor
        if isinstance(features, np.ndarray):
            features = torch.from_numpy(features).float()
        
        # Add batch dimension if needed
        if len(features.shape) == 2:
            features = features.unsqueeze(0)
        
        features = features.to(self.device)
        
        # Run model
        self.model.eval()
        with torch.no_grad():
            anomaly_scores, class_logits = self.model(features)
        
        scores = anomaly_scores.squeeze().cpu().numpy()
        if scores.ndim == 0:
            scores = np.array([scores])
        
        # Build result
        max_score = float(scores.max())
        is_anomalous = max_score >= self.config.anomaly_threshold
        
        result = {
            'video_id': video_id,
            'camera': camera,
            'is_anomalous': is_anomalous,
            'max_score': max_score,
            'scores': scores.tolist(),
            'detections': []
        }
        
        if is_anomalous:
            peak_idx = int(scores.argmax())
            
            # Get class probabilities at peak
            if class_logits.dim() == 3:
                probs = torch.softmax(class_logits[0, peak_idx], dim=0).cpu().numpy()
            else:
                probs = torch.softmax(class_logits[0], dim=0).cpu().numpy()
            
            crime_idx = int(probs[1:].argmax()) + 1  # Skip Normal class
            
            # Calculate timing
            segment_duration = total_frames / (len(scores) * fps)
            start_time = peak_idx * segment_duration
            end_time = (peak_idx + 1) * segment_duration
            
            result['detections'].append({
                'crime_type': self.config.classes[crime_idx],
                'confidence': float(probs[crime_idx]),
                'start_time': str(timedelta(seconds=int(start_time))),
                'end_time': str(timedelta(seconds=int(end_time))),
                'anomaly_score': max_score,
                'all_probabilities': {
                    self.config.classes[i]: float(probs[i])
                    for i in range(len(self.config.classes))
                }
            })
        
        return result
